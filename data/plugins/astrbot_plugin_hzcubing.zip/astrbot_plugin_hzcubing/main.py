import asyncio
import json
import os
from pathlib import Path
from urllib.parse import quote
from typing import Any

import aiohttp
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, register
from astrbot.api import logger

from .one_api import PersonalRecordAPIClient, OneRecordHandler

# API 配置
API_BASE_URL = "https://backend.hzcubing.club/astrobot-hzcubing"
REQUEST_TIMEOUT = 10  # 请求超时时间（秒）

# 官方项目顺序列表（用于排序）
OFFICIAL_EVENT_ORDER = [
    "333",     # 三阶速拧
    "222",     # 二阶速拧
    "333oh",   # 三阶单手
    "444",     # 四阶速拧
    "555",     # 五阶速拧
    "666",     # 六阶速拧
    "777",     # 七阶速拧
    "meg",     # 五魔方
    "333bf",   # 三阶盲拧
    "444bf",   # 四阶盲拧
    "555bf",   # 五阶盲拧
    "333fm",   # 最少步
    "py",      # 金字塔
    "sk",      # 斜转
    "sq1",     # SQ1
    "clock",   # 魔表
    "333mbf",  # 多盲
    "fto",     # FTO
]

# 官方项目代码集合（用于验证和过滤）
OFFICIAL_EVENT_CODES = set(OFFICIAL_EVENT_ORDER)

# 项目名称映射表（中文 -> 项目代码）
EVENT_NAME_MAP = {
    # 三阶速拧
    "三阶速拧": "333",
    "三阶": "333",
    "333": "333",
    # 二阶速拧
    "二阶速拧": "222",
    "二阶": "222",
    "222": "222",
    # 三阶单手
    "三阶单手": "333oh",
    "单手": "333oh",
    "333oh": "333oh",
    # 四阶速拧
    "四阶速拧": "444",
    "四阶": "444",
    "444": "444",
    # 五阶速拧
    "五阶速拧": "555",
    "五阶": "555",
    "555": "555",
    # 六阶速拧
    "六阶速拧": "666",
    "六阶": "666",
    "666": "666",
    # 七阶速拧
    "七阶速拧": "777",
    "七阶": "777",
    "777": "777",
    # 五魔方
    "五魔方": "meg",
    "meg": "meg",
    # 三阶盲拧
    "三阶盲拧": "333bf",
    "333bf": "333bf",
    # 四阶盲拧
    "四阶盲拧": "444bf",
    "444bf": "444bf",
    # 五阶盲拧
    "五阶盲拧": "555bf",
    "555bf": "555bf",
    # 最少步
    "最少步": "333fm",
    "333fm": "333fm",
    # 金字塔
    "金字塔": "py",
    "py": "py",
    # 斜转
    "斜转": "sk",
    "sk": "sk",
    # SQ1
    "SQ1": "sq1",
    "sq1": "sq1",
    # 魔表
    "魔表": "clock",
    "clock": "clock",
    # 多盲
    "多盲": "333mbf",
    "333mbf": "333mbf",
    # FTO
    "FTO": "fto",
    "fto": "fto",
}

# 项目代码到中文名称的映射（用于显示）
EVENT_CODE_TO_CN = {
    "333": "三阶",
    "222": "二阶",
    "333oh": "三单",
    "444": "四阶",
    "555": "五阶",
    "666": "六阶",
    "777": "七阶",
    "meg": "五魔",
    "333bf": "三盲",
    "444bf": "四盲",
    "555bf": "五盲",
    "333fm": "最少步",
    "py": "金字塔",
    "sk": "斜转",
    "sq1": "SQ1",
    "clock": "魔表",
    "333mbf": "多盲",
    "fto": "FTO",
}

# 排行榜类型映射表（中文 -> 英文）
RANK_TYPE_MAP = {
    "单次": "single",
    "single": "single",
    "平均": "average",
    "average": "average",
}



def format_time_ms(time_ms: int | None) -> str:
    """格式化时间（毫秒格式转换为秒格式）
    
    时间格式：分秒毫秒（6位数字）
    例如：15230 = 1分52秒30 = 1:52.30
         1245 = 12秒45 = 12.45
         999999 = DNF
    """
    if not time_ms or time_ms == 999999:
        return "DNF"
    
    try:
        time_ms_int = int(time_ms)
        if time_ms_int <= 0 or time_ms_int == 999999:
            return "DNF"
        
        time_str = str(time_ms_int).zfill(6)
        minutes = int(time_str[:2])
        seconds = int(time_str[2:4])
        milliseconds = time_str[4:6]
        
        if minutes > 0:
            return f"{minutes}:{seconds}.{milliseconds}"
        else:
            return f"{seconds}.{milliseconds}"
    except (ValueError, TypeError):
        return "DNF"


def format_time_seconds(time_seconds: float | int | None) -> str:
    """格式化时间（秒数格式转换为分:秒.毫秒格式）
    
    例如：62.01 -> 1:02.01
         45.23 -> 45.23
         120.50 -> 2:00.50
         69.00 -> 1:09.00
    """
    if time_seconds is None:
        return "-"
    
    try:
        total_seconds = float(time_seconds)
        if total_seconds <= 0:
            return "-"
        
        minutes = int(total_seconds // 60)
        seconds = total_seconds % 60
        
        if minutes > 0:
            # 格式：分:秒.毫秒（秒数保留2位小数，秒数部分补零到两位数）
            # 使用05.2f格式，然后手动处理秒数部分
            seconds_int = int(seconds)
            seconds_remainder = seconds - seconds_int
            
            if abs(seconds_remainder) < 0.001:
                # 无小数部分：分:秒（补零到两位数）
                return f"{minutes}:{seconds_int:02d}"
            else:
                # 有小数部分：分:秒.毫秒
                # 确保秒数部分是两位数，小数部分保留2位
                return f"{minutes}:{seconds_int:02d}.{seconds_remainder:.2f}".rstrip("0").rstrip(".")
        else:
            # 格式：秒.毫秒（保留2位小数）
            return f"{seconds:.2f}"
    except (ValueError, TypeError):
        return "-"


class APIClient:
    """API 客户端类，用于调用测试接口"""

    def __init__(self, base_url: str = API_BASE_URL, timeout: int = REQUEST_TIMEOUT):
        self.base_url = base_url
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session: aiohttp.ClientSession | None = None

    async def _ensure_session(self):
        """确保 HTTP session 存在"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self.session

    async def _request(
        self,
        action: str,
        method: str = "GET",
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """发送 HTTP 请求"""
        session = await self._ensure_session()
        
        try:
            if method.upper() == "GET":
                async with session.get(
                    self.base_url, params=params or {}
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        text = await response.text()
                        return {
                            "code": response.status,
                            "message": f"请求失败，状态码：{response.status}",
                            "error": text,
                        }
            else:  # POST
                async with session.post(
                    self.base_url, json=data or {}
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        text = await response.text()
                        return {
                            "code": response.status,
                            "message": f"请求失败，状态码：{response.status}",
                            "error": text,
                        }
        except asyncio.TimeoutError:
            return {
                "code": 500,
                "message": "请求超时",
                "error": f"请求超时（{self.timeout.total}秒）",
            }
        except Exception as e:
            logger.error(f"API 请求异常: {e}")
            return {
                "code": 500,
                "message": "请求异常",
                "error": str(e),
            }

    # async def leaderboard(
    #     self,
    #     event: str,
    #     rank_type: str = "single",
    #     limit: int | None = None,
    # ) -> dict[str, Any]:
    #     """Leaderboard 测试 - 项目排行榜"""
    #     params: dict[str, Any] = {
    #         "action": "leaderboard",
    #         "event": event,
    #         "rankType": rank_type,
    #     }
    #     if limit is not None:
    #         params["limit"] = limit
    #     return await self._request("leaderboard", method="GET", params=params)

    # async def record_history(
    #     self,
    #     event: str,
    #     page: int = 1,
    #     page_size: int = 10,
    # ) -> dict[str, Any]:
    #     """Record History - 项目历史记录（打破记录的记录）"""
    #     params: dict[str, Any] = {
    #         "action": "record-history",
    #         "event": event,
    #         "page": page,
    #         "pageSize": page_size,
    #     }
    #     return await self._request("record-history", method="GET", params=params)

    # async def best_records(
    #     self,
    #     event: str | None = None,
    # ) -> dict[str, Any]:
    #     """Best Records - 各项目最佳记录（GR记录）"""
    #     params: dict[str, Any] = {
    #         "action": "best-records",
    #     }
    #     if event:
    #         params["event"] = event
    #     return await self._request("best-records", method="GET", params=params)

    # async def close(self):
    #     """关闭 session"""
    #     if self.session and not self.session.closed:
    #         await self.session.close()


def normalize_event_code(event: str) -> str | None:
    """将中文项目名称或项目代码标准化为官方项目代码"""
    event = event.strip()
    # 如果已经在映射表中，直接返回
    if event in EVENT_NAME_MAP:
        return EVENT_NAME_MAP[event]
    # 如果直接是官方项目代码，返回
    if event in OFFICIAL_EVENT_CODES:
        return event
    return None


def normalize_rank_type(rank_type: str) -> str | None:
    """将中文排行榜类型或英文类型标准化为英文类型"""
    rank_type = rank_type.strip().lower()
    if rank_type in RANK_TYPE_MAP:
        return RANK_TYPE_MAP[rank_type]
    return None


@register("astrbot_plugin_hzcubing", "huizhi", "会枝cubing 测试插件", "1.0.0")
class HZCubingPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self.api_client = APIClient()
        self.personal_record_client = PersonalRecordAPIClient()
        # 初始化one记录处理器
        self.one_handler = OneRecordHandler(
            self.personal_record_client,
            format_time_ms
        )

    async def initialize(self):
        """插件初始化"""
        logger.info("会枝cubing 测试插件已加载")

    async def terminate(self):
        """插件销毁时关闭 API 客户端"""
        await self.api_client.close()
        await self.personal_record_client.close()
        logger.info("会枝cubing 测试插件已卸载")


    # @filter.command("排行榜", alias={"leaderboard", "rank", "排名"})
    # async def leaderboard_command(self, event: AstrMessageEvent):
    #     """项目排行榜 - 获取指定项目的排行榜信息
        
    #     用法:
    #     /排行榜 <项目> [类型] [数量]
    #     参数:
    #     • 项目: 项目代码或中文名称（必填），如 333、三阶速拧 等
    #     • 类型: 单次 或 平均，默认为 单次
    #     • 数量: 可选，限制返回前N名
    #     示例:
    #     /排行榜 333
    #     /排行榜 三阶速拧 平均
    #     /排行榜 333 单次 10
    #     """
    #     cmd_tokens = self.parse_commands(event.message_str)
        
    #     # 获取项目代码（必需参数）
    #     event_code_str = cmd_tokens.get(1)
    #     if not event_code_str:
    #         yield event.plain_result(
    #             "❌ 请指定项目代码或名称\n用法: /排行榜 <项目> [类型] [数量]\n示例: /排行榜 333\n示例: /排行榜 三阶速拧 平均"
    #         ).use_t2i(False)
    #         return
        
    #     # 标准化项目代码
    #     event_code = normalize_event_code(event_code_str)
    #     if not event_code or event_code not in OFFICIAL_EVENT_CODES:
    #         yield event.plain_result(
    #             f"❌ 无效的项目代码或名称: {event_code_str}\n支持的项目请使用 麦麦帮助 查看"
    #         ).use_t2i(False)
    #         return
        
    #     # 获取排行榜类型（可选，默认 single）
    #     rank_type_str = cmd_tokens.get(2)
    #     rank_type = "single"  # 默认值
    #     if rank_type_str:
    #         normalized = normalize_rank_type(rank_type_str)
    #         if normalized:
    #             rank_type = normalized
    #         else:
    #             yield event.plain_result(
    #                 f"❌ 无效的排行榜类型: {rank_type_str}\n支持的类型: 单次 或 平均\n示例: /排行榜 333 单次"
    #             ).use_t2i(False)
    #             return
        
    #     # 获取数量限制（可选）
    #     limit = None
    #     limit_str = cmd_tokens.get(3)
    #     if limit_str:
    #         try:
    #             limit = int(limit_str)
    #             if limit <= 0:
    #                 limit = None
    #         except (ValueError, TypeError):
    #             limit = None
        
    #     try:
    #         result = await self.api_client.leaderboard(
    #             event=event_code, rank_type=rank_type, limit=limit
    #         )
            
    #         if result.get("code") == 200:
    #             data = result.get("data", {})
    #             leaderboard = data.get("leaderboard", [])
    #             event_name = data.get("event", event_code)
    #             rank_type_name = data.get("rankType", rank_type)
    #             count = data.get("count", 0)
                
    #             # 排行榜类型中文名称
    #             rank_type_cn = "单次成绩" if rank_type_name == "single" else "平均成绩"
                
    #             if not leaderboard:
    #                 response_text = f"✅ {event_name} {rank_type_cn}排行榜\n暂无记录"
    #             else:
    #                 lines = [
    #                     f"✅ {event_name} {rank_type_cn}排行榜 (共 {count} 人):"
    #                 ]
    #                 for entry in leaderboard:
    #                     rank = entry.get("rank", 0)
    #                     nickname = entry.get("nickname") or "匿名用户"
    #                     time_value = entry.get("time")
                        
    #                     # 处理成绩值
    #                     if time_value is None:
    #                         continue  # 跳过无效成绩
                        
    #                     try:
    #                         time_str = format_time_seconds(float(time_value))
    #                         if time_str != "-":
    #                             time_str += "s"
    #                     except (ValueError, TypeError):
    #                         continue  # 跳过无效成绩
                        
    #                     lines.append(
    #                         f"{rank}. {nickname} - {time_str}"
    #                     )
                    
    #                 response_text = "\n".join(lines)
    #                 yield event.plain_result(response_text).use_t2i(False)
    #         else:
    #             error_msg = result.get("message", "未知错误")
    #             response_text = f"❌ 获取排行榜失败\n错误: {error_msg}"
    #             yield event.plain_result(response_text).use_t2i(False)
    #     except Exception as e:
    #         logger.error(f"排行榜命令异常: {e}")
    #         yield event.plain_result(f"❌ 执行出错: {str(e)}").use_t2i(False)

    # @filter.command("历史gr", alias={"历史记录", "历史GR"})
    # async def record_history_command(self, event: AstrMessageEvent):
    #     """历史GR记录 - 获取指定项目打破记录的记录
        
    #     用法:
    #     /历史gr <项目>
    #     示例: /历史gr 333
    #     """
    #     cmd_tokens = self.parse_commands(event.message_str)
        
    #     # 获取项目代码（必需参数）
    #     event_code_str = cmd_tokens.get(1)
    #     if not event_code_str:
    #         yield event.plain_result(
    #             "❌ 请指定项目代码或名称\n用法: /历史gr <项目>\n示例: /历史gr 333\n示例: /历史gr 三阶速拧"
    #         ).use_t2i(False)
    #         return
        
    #     # 标准化项目代码
    #     event_code = normalize_event_code(event_code_str)
    #     if not event_code or event_code not in OFFICIAL_EVENT_CODES:
    #         yield event.plain_result(
    #             f"❌ 无效的项目代码或名称: {event_code_str}\n支持的项目请使用 麦麦帮助 查看"
    #         ).use_t2i(False)
    #         return
        
    #     try:
    #         result = await self.api_client.record_history(event=event_code, page=1, page_size=100)
            
    #         if result.get("code") == 200:
    #             data = result.get("data", {})
    #             records = data.get("records", [])
    #             event_name = data.get("event", event_code)
                
    #             if not records:
    #                 response_text = f"✅ {event_name} 历史GR记录\n暂无打破记录的历史"
    #             else:
    #                 # 分别收集单次记录和平均记录
    #                 single_records = []
    #                 average_records = []
                    
    #                 for record in records:
    #                     nickname = record.get("nickname") or "匿名用户"
    #                     single_seconds = record.get("singleSeconds")
    #                     average_seconds = record.get("averageSeconds")
    #                     is_single_record = record.get("isSingleRecord", False)
    #                     is_average_record = record.get("isAverageRecord", False)
                        
    #                     # 收集单次记录
    #                     if is_single_record and single_seconds is not None:
    #                         try:
    #                             time_str = format_time_seconds(float(single_seconds))
    #                             if time_str != "-":
    #                                 single_records.append(f"{nickname} {time_str}")
    #                         except (ValueError, TypeError):
    #                             pass
                        
    #                     # 收集平均记录
    #                     if is_average_record and average_seconds is not None:
    #                         try:
    #                             time_str = format_time_seconds(float(average_seconds))
    #                             if time_str != "-":
    #                                 average_records.append(f"{nickname} {time_str}")
    #                         except (ValueError, TypeError):
    #                             pass
                    
    #                 # 构建输出
    #                 lines = []
                    
    #                 # 显示单次记录
    #                 if single_records:
    #                     lines.append("单次：")
    #                     lines.extend(single_records)
    #                     # 如果还有平均记录，添加空行分隔
    #                     if average_records:
    #                         lines.append("")
                    
    #                 # 显示平均记录
    #                 if average_records:
    #                     lines.append("平均：")
    #                     lines.extend(average_records)
                    
    #                 response_text = "\n".join(lines)
    #                 yield event.plain_result(response_text).use_t2i(False)
    #         else:
    #             error_msg = result.get("message", "未知错误")
    #             response_text = f"❌ 获取历史记录失败\n错误: {error_msg}"
    #             yield event.plain_result(response_text).use_t2i(False)
    #     except Exception as e:
    #         logger.error(f"历史GR记录命令异常: {e}")
    #         yield event.plain_result(f"❌ 执行出错: {str(e)}").use_t2i(False)

    # @filter.command("gr", alias={"GR", "最佳记录", "gr记录"})
    # async def best_records_command(self, event: AstrMessageEvent):
    #     """GR记录 - 获取各项目最佳记录（单次和平均）
        
    #     用法:
    #     /gr - 获取所有项目的最佳记录
    #     /gr <项目> - 获取指定项目的最佳记录
    #     示例: /gr
    #     示例: /gr 333
    #     """
    #     cmd_tokens = self.parse_commands(event.message_str)
        
    #     # 获取项目代码（可选参数）
    #     event_code_str = cmd_tokens.get(1)
    #     event_code = None
    #     if event_code_str:
    #         event_code = normalize_event_code(event_code_str)
    #         if not event_code or event_code not in OFFICIAL_EVENT_CODES:
    #             yield event.plain_result(
    #                 f"❌ 无效的项目代码或名称: {event_code_str}\n支持的项目请使用 麦麦帮助 查看"
    #             ).use_t2i(False)
    #             return
        
    #     try:
    #         result = await self.api_client.best_records(event=event_code)
            
    #         if result.get("code") == 200:
    #             data = result.get("data", {})
    #             best_records = data.get("bestRecords", [])
                
    #             if not best_records:
    #                 response_text = "✅ GR记录\n暂无记录"
    #                 yield event.plain_result(response_text).use_t2i(False)
    #             else:
    #                 lines = []
    #                 # 创建事件代码到记录的映射
    #                 event_to_record = {}
    #                 for record in best_records:
    #                     event_name = record.get("event", "")
    #                     if event_name in OFFICIAL_EVENT_CODES:
    #                         event_to_record[event_name] = record
                    
    #                 sorted_events = sorted(
    #                     event_to_record.keys(),
    #                     key=lambda x: OFFICIAL_EVENT_ORDER.index(x) if x in OFFICIAL_EVENT_ORDER else len(OFFICIAL_EVENT_ORDER)
    #                 )
                    
    #                 for event_name in sorted_events:
    #                     record = event_to_record[event_name]
    #                     single = record.get("single")
    #                     average = record.get("average")
                        
    #                     single_text = "-"
    #                     single_nickname = ""
    #                     if single:
    #                         single_seconds = single.get("seconds")
    #                         single_nickname = single.get("holderNickname") or "匿名用户"
    #                         if single_seconds is not None:
    #                             try:
    #                                 single_text = format_time_seconds(float(single_seconds))
    #                             except (ValueError, TypeError):
    #                                 single_text = "-"
                        
    #                     average_text = "-"
    #                     average_nickname = ""
    #                     if average:
    #                         average_seconds = average.get("seconds")
    #                         average_nickname = average.get("holderNickname") or "匿名用户"
    #                         if average_seconds is not None:
    #                             try:
    #                                 average_text = format_time_seconds(float(average_seconds))
    #                             except (ValueError, TypeError):
    #                                 average_text = "-"
                        
    #                     if single_text != "-" or average_text != "-":
    #                         # 格式化输出：项目代码 单次成绩 || 平均成绩
    #                         if event_code:
    #                             # 单个项目
    #                             lines.append(f"{event_name} {single_text} || {average_text}")
    #                         else:
    #                             # 所有项目：项目 单次昵称 单次成绩 || 平均成绩 平均昵称
    #                             if single_text != "-" and average_text != "-":
    #                                 lines.append(f"{event_name} {single_nickname} {single_text} || {average_text} {average_nickname}")
    #                             elif single_text != "-":
    #                                 lines.append(f"{event_name} {single_nickname} {single_text} || -")
    #                             else:
    #                                 lines.append(f"{event_name} - || {average_text} {average_nickname}")
                    
    #                 if not lines:
    #                     response_text = "✅ GR记录\n暂无有效记录"
    #                 else:
    #                     response_text = "✅ GR记录\n" + "\n".join(lines)
    #                 yield event.plain_result(response_text).use_t2i(False)
    #         else:
    #             error_msg = result.get("message", "未知错误")
    #             response_text = f"❌ 获取GR记录失败\n错误: {error_msg}"
    #             yield event.plain_result(response_text).use_t2i(False)
    #     except Exception as e:
    #         logger.error(f"GR记录命令异常: {e}")
    #         yield event.plain_result(f"❌ 执行出错: {str(e)}").use_t2i(False)

#     @filter.command("帮助", alias={"help", "h", "?"})
#     async def help_command(self, event: AstrMessageEvent):
#         """帮助命令 - 显示所有可用命令的说明"""
#         help_text = """会枝cubing 网站助手

# 📋 可用命令列表：

# 1️⃣ 项目排行榜
#    命令: /排行榜 <项目> [类型] [数量]
#    功能: 获取指定项目的排行榜信息
#    参数:
#      • 项目: 项目代码或中文名称（必填），如 333、三阶速拧 等
#      • 类型: 单次 或 平均，默认为 单次
#      • 数量: 可选，限制返回前N名
#    示例:
#      /排行榜 333
#      /排行榜 三阶速拧 平均
#      /排行榜 333 单次 10
#    别名: /排行榜 = /leaderboard = /rank = /排名

# 2️⃣ 历史GR记录
#    命令: /历史gr <项目>
#    功能: 获取指定项目打破记录的记录，按时间排序（最新的在前）
#    参数:
#      • 项目: 项目代码或中文名称（必填），如 333、三阶速拧 等
#    示例:
#      /历史gr 333
#      /历史gr 三阶速拧
#    别名: /历史gr = /历史记录 = /历史GR

# 3️⃣ GR记录
#    命令: /gr [项目]
#    功能: 获取各项目最佳记录（单次和平均），不填项目参数默认返回全部
#    参数:
#      • 项目: 项目代码或中文名称（可选），如 333、三阶速拧 等
#    示例:
#      /gr
#      /gr 333
#    别名: /gr = /GR = /最佳记录 = /gr记录

# 4️⃣ 个人记录查询
#    命令: /one <姓名或ID>
#    功能: 查询选手的个人最佳记录（PB）
#    参数:
#      • 姓名或ID: 选手姓名或用户ID（必填）
#    示例:
#      /one 张三
#      /one 12345
#    别名: /one = /查记录 = /查PB = /记录 = /PB = /个人记录

# 5️⃣ 选手PK对比
#    命令: /onepk <姓名1或ID1> <姓名2或ID2>
#    功能: 对比两个选手的个人成绩，显示各项目的胜负情况
#    参数:
#      • 姓名1或ID1: 第一个选手的姓名或用户ID（必填）
#      • 姓名2或ID2: 第二个选手的姓名或用户ID（必填）
#    示例:
#      /onepk 张三 李四
#      /onepk 12345 67890
#    别名: /onepk = /pk = /PK = /对比

# 📌 官方支持的项目:
#    333 / 三阶速拧
#    222 / 二阶速拧
#    333oh / 三阶单手
#    444 / 四阶速拧
#    555 / 五阶速拧
#    666 / 六阶速拧
#    777 / 七阶速拧
#    meg / 五魔方
#    333bf / 三阶盲拧
#    444bf / 四阶盲拧
#    555bf / 五阶盲拧
#    333fm / 最少步
#    py / 金字塔
#    sk / 斜转
#    sq1 / SQ1
#    clock / 魔表
#    333mbf / 多盲
#    fto / FTO"""
#         yield event.plain_result(help_text).use_t2i(False)

    @filter.command("one", alias={"查记录", "查PB", "记录", "PB", "个人记录"})
    async def personal_record_command(self, event: AstrMessageEvent):
        """个人记录查询 - 根据姓名或ID查询选手的个人最佳记录
        
        用法:
        /one <姓名或ID>
        示例: /one 张三
        示例: /one 12345
        """
        async for result in self.one_handler.personal_record_command(event, self.parse_commands):
            yield result

    @filter.command("onepk", alias={"pk", "PK", "对比"})
    async def pk_command(self, event: AstrMessageEvent):
        """选手PK对比 - 对比两个选手的个人成绩
        
        用法:
        /onepk <姓名1或ID1> <姓名2或ID2>
        示例: /onepk 张三 李四
        示例: /onepk 12345 67890
        """
        async for result in self.one_handler.pk_command(event, self.parse_commands):
            yield result
