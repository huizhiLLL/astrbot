import asyncio
import json
from urllib.parse import quote
from typing import Any

import aiohttp
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api import logger

# 个人记录API配置
PERSONAL_RECORD_API_BASE = "https://ss.sxmfxh.com"
REQUEST_TIMEOUT = 10  # 请求超时时间（秒）

# 项目ID到项目代码的映射表
EVENT_ID_TO_CODE = {
    1: "333",       # 三阶
    2: "222",       # 二阶
    3: "444",       # 四阶
    4: "555",       # 五阶
    5: "666",       # 六阶
    6: "777",       # 七阶
    7: "333oh",     # 三阶单手
    8: "pyram",     # 金字塔
    9: "skewb",     # 斜转
    10: "minx",     # 五魔方
    11: "333bf",    # 三阶盲拧
    12: "444bf",    # 四阶盲拧
    13: "555bf",    # 五阶盲拧
    14: "333mbld",  # 三阶多盲
    15: "sq1",      # SQ1
    16: "333fm",    # 最少步
    17: "clock",    # 魔表
    18: "枫叶",   # 枫叶
    19: "FTO",      # FTO
    20: "镜面",   # 镜面
    41: "智能三阶", # 智能三阶
    42: "智能三单", # 智能三单
    43: "智能二阶", # 智能二阶
    61: "三阶单面", # 三阶单面
    90: "参赛包",
    91: "趣味1",
    92: "趣味2",
    93: "趣味3",
    94: "趣味4",
    95: "趣味5",
    99: "趣味项目",
    101: "竞技叠杯",
    106: "三国华容道",
    114: "四阶华容道",
}


def parse_time_to_ms(time_str: str) -> int | None:
    """将时间字符串转换为毫秒数，用于比较
    
    支持的格式：
    - "8.52" -> 8520毫秒
    - "1:04.95" -> 64950毫秒
    - "DNF" 或 "-" -> None
    """
    if not time_str or time_str.upper() in ("DNF", "-", ""):
        return None
    
    try:
        if ":" in time_str:
            # 格式：分:秒.毫秒
            parts = time_str.split(":")
            minutes = int(parts[0])
            seconds_part = parts[1]
            seconds_parts = seconds_part.split(".")
            seconds = int(seconds_parts[0])
            milliseconds = int(seconds_parts[1]) if len(seconds_parts) > 1 else 0
            return (minutes * 60 + seconds) * 1000 + milliseconds * 10
        else:
            # 格式：秒.毫秒
            parts = time_str.split(".")
            seconds = int(parts[0])
            milliseconds = int(parts[1]) if len(parts) > 1 else 0
            return seconds * 1000 + milliseconds * 10
    except (ValueError, TypeError, IndexError):
        return None


def compare_times(time1_ms: int | None, time2_ms: int | None) -> int:
    """比较两个时间，返回值：1表示time1更好（更小），-1表示time2更好，0表示平局或都无效
    
    如果一方无效（None），另一方获胜
    """
    if time1_ms is None and time2_ms is None:
        return 0  # 都无效，平局
    if time1_ms is None:
        return -1  # time2获胜
    if time2_ms is None:
        return 1  # time1获胜
    if time1_ms < time2_ms:
        return 1  # time1获胜
    elif time1_ms > time2_ms:
        return -1  # time2获胜
    else:
        return 0  # 平局


class PersonalRecordAPIClient:
    """个人记录查询API客户端类"""

    def __init__(self, base_url: str = PERSONAL_RECORD_API_BASE, timeout: int = REQUEST_TIMEOUT):
        self.base_url = base_url
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session: aiohttp.ClientSession | None = None

    async def _ensure_session(self):
        """确保 HTTP session 存在"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self.session

    async def search_user(self, search_input: str, page: int = 1, size: int = 5) -> dict[str, Any]:
        """搜索用户信息
        
        Args:
            search_input: 搜索关键词（姓名或ID）
            page: 页码，默认1
            size: 每页数量，默认5
        """
        session = await self._ensure_session()
        
        query_params = {
            "searchInput": search_input,
            "page": page,
            "size": size,
        }
        query_json = json.dumps(query_params, ensure_ascii=False)
        url = f"{self.base_url}/users/getUsers?query={quote(query_json)}"
        
        try:
            async with session.post(url) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    text = await response.text()
                    return {
                        "code": response.status,
                        "err": f"请求失败，状态码：{response.status}",
                        "error": text,
                    }
        except asyncio.TimeoutError:
            return {
                "code": 500,
                "err": "请求超时",
                "error": f"请求超时（{self.timeout.total}秒）",
            }
        except Exception as e:
            logger.error(f"搜索用户API请求异常: {e}")
            return {
                "code": 500,
                "err": "请求异常",
                "error": str(e),
            }

    async def get_personal_records(self, u_id: int) -> dict[str, Any]:
        """获取用户个人记录
        
        Args:
            u_id: 用户ID
        """
        session = await self._ensure_session()
        
        query_params = {"u_id": u_id}
        query_json = json.dumps(query_params)
        url = f"{self.base_url}/grades/getGradesAndRank?query={quote(query_json)}"
        
        try:
            async with session.post(url) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    text = await response.text()
                    return {
                        "code": response.status,
                        "err": f"请求失败，状态码：{response.status}",
                        "error": text,
                    }
        except asyncio.TimeoutError:
            return {
                "code": 500,
                "err": "请求超时",
                "error": f"请求超时（{self.timeout.total}秒）",
            }
        except Exception as e:
            logger.error(f"获取个人记录API请求异常: {e}")
            return {
                "code": 500,
                "err": "请求异常",
                "error": str(e),
            }

    async def close(self):
        """关闭 session"""
        if self.session and not self.session.closed:
            await self.session.close()


class OneRecordHandler:
    """个人记录查询和PK对比处理器"""
    
    def __init__(self, personal_record_client: PersonalRecordAPIClient, format_time_ms_func):
        """
        Args:
            personal_record_client: 个人记录API客户端
            format_time_ms_func: 格式化时间的函数
        """
        self.personal_record_client = personal_record_client
        self.format_time_ms = format_time_ms_func

    async def _resolve_user(self, search_input: str) -> tuple[int | None, str | None, str | None]:
        """解析用户（通过姓名或ID）
        
        返回: (u_id, user_name, error_message)
        如果error_message不为None，表示解析失败
        """
        search_input = search_input.strip()
        
        # 如果是纯数字，直接作为ID
        if search_input.isdigit():
            return int(search_input), None, None
        
        # 是姓名，先搜索用户
        search_result = await self.personal_record_client.search_user(
            search_input, page=1, size=5
        )
        
        if search_result.get("code") != 10000:
            error_msg = search_result.get("err", "未知错误")
            return None, None, f"❌ 搜索用户失败\n错误: {error_msg}"
        
        users = search_result.get("data", [])
        if not users:
            return None, None, f"❌ 未找到用户: {search_input}"
        
        # 严格匹配：只查找完全相同的姓名（不包含部分匹配）
        exact_matches = [
            user for user in users
            if user.get("u_name") == search_input
        ]
        
        if not exact_matches:
            return None, None, (
                f"❌ 未找到完全匹配的用户「{search_input}」\n"
                f"提示：姓名查询需要完全匹配，请检查输入是否正确\n"
                f"如需模糊搜索，请使用用户ID查询"
            )
        
        # 如果有多个同名用户，返回错误提示
        if len(exact_matches) > 1:
            lines = [f"❌ 找到多个同名用户「{search_input}」，请使用ID查询：\n"]
            for i, user in enumerate(exact_matches, 1):
                u_id_item = user.get("u_id")
                u_name_item = user.get("u_name")
                lines.append(f"{i}. {u_name_item}（ID: {u_id_item}）")
            lines.append(f"\n使用方法: 使用ID进行查询")
            return None, None, "\n".join(lines)
        
        # 只有一个精确匹配，直接使用
        u_id = exact_matches[0].get("u_id")
        user_name = exact_matches[0].get("u_name")
        return u_id, user_name, None

    async def personal_record_command(self, event: AstrMessageEvent, parse_commands_func):
        """个人记录查询 - 根据姓名或ID查询选手的个人最佳记录
        
        用法:
        /one <姓名或ID>
        示例: /one 张三
        示例: /one 12345
        """
        cmd_tokens = parse_commands_func(event.message_str)
        
        # 获取搜索关键词（姓名或ID）
        search_input = cmd_tokens.get(1)
        if not search_input:
            yield event.plain_result(
                "❌ 请提供姓名或ID\n用法: /one <姓名或ID>\n示例: /one 张三\n示例: /one 12345"
            ).use_t2i(False)
            return
        
        try:
            # 解析用户
            u_id, user_name, error_msg = await self._resolve_user(search_input)
            if error_msg:
                yield event.plain_result(error_msg).use_t2i(False)
                return
            
            # 获取个人记录
            records_result = await self.personal_record_client.get_personal_records(u_id)
            
            if records_result.get("code") != 10000:
                error_msg = records_result.get("err", "未知错误")
                yield event.plain_result(f"❌ 获取个人记录失败\n错误: {error_msg}").use_t2i(False)
                return
            
            rank_data = records_result.get("data", {}).get("rank", [])
            if not rank_data:
                yield event.plain_result(f"❌ {user_name or '该用户'} 暂无个人记录").use_t2i(False)
                return
            
            # 如果没有user_name，从第一条记录获取
            if not user_name and rank_data:
                user_name = rank_data[0].get("u_name", "未知用户")
            
            # 获取用户ID（如果还没有）
            if not u_id and rank_data:
                u_id = rank_data[0].get("u_id")
            
            # 格式化显示
            header = f"{user_name}（{u_id}）的one平台成绩为："
            lines = []
            
            # 按项目ID排序
            sorted_records = sorted(rank_data, key=lambda x: x.get("e_id", 0))
            
            for record in sorted_records:
                e_id = record.get("e_id")
                
                # 获取项目代码，如果没有映射则使用项目ID
                event_code = EVENT_ID_TO_CODE.get(e_id)
                if not event_code:
                    # 对于未知项目，使用项目ID作为代码
                    event_code = f"项目{e_id}"
                
                time_single_ms = record.get("time_single")
                time_avg_ms = record.get("time_avg")
                
                # 格式化单次成绩
                single_time = "-"
                if time_single_ms and time_single_ms != 999999:
                    single_time = self.format_time_ms(time_single_ms)
                
                # 格式化平均成绩
                avg_time = "-"
                if time_avg_ms and time_avg_ms != 999999:
                    avg_time = self.format_time_ms(time_avg_ms)
                
                # 跳过两个成绩都是无效的记录
                if single_time == "-" and avg_time == "-":
                    continue
                
                # 格式：项目代码 单次成绩 || 平均成绩
                lines.append(f"{event_code}  {single_time} || {avg_time}")
            
            if not lines:
                response_text = f"❌ {user_name} 暂无有效个人记录"
                yield event.plain_result(response_text).use_t2i(False)
            else:
                response_text = f"{header}\n" + "\n".join(lines)
                yield event.plain_result(response_text).use_t2i(False)
            
        except Exception as e:
            logger.error(f"个人记录查询异常: {e}")
            yield event.plain_result(f"❌ 执行出错: {str(e)}").use_t2i(False)

    async def pk_command(self, event: AstrMessageEvent, parse_commands_func):
        """选手PK对比 - 对比两个选手的个人成绩
        
        用法:
        /onepk <姓名1或ID1> <姓名2或ID2>
        示例: /onepk 张三 李四
        示例: /onepk 12345 67890
        """
        cmd_tokens = parse_commands_func(event.message_str)
        
        # 获取两个选手的搜索关键词
        search_input1 = cmd_tokens.get(1)
        search_input2 = cmd_tokens.get(2)
        
        if not search_input1 or not search_input2:
            yield event.plain_result(
                "❌ 请提供两个选手的姓名或ID\n用法: /onepk <姓名1或ID1> <姓名2或ID2>\n示例: /onepk 张三 李四\n示例: /onepk 12345 67890"
            ).use_t2i(False)
            return
        
        try:
            # 解析第一个用户
            u_id1, user_name1, error_msg1 = await self._resolve_user(search_input1)
            if error_msg1:
                yield event.plain_result(f"❌ 解析第一个用户失败：\n{error_msg1}").use_t2i(False)
                return
            
            # 解析第二个用户
            u_id2, user_name2, error_msg2 = await self._resolve_user(search_input2)
            if error_msg2:
                yield event.plain_result(f"❌ 解析第二个用户失败：\n{error_msg2}").use_t2i(False)
                return
            
            # 获取两个用户的个人记录
            records_result1 = await self.personal_record_client.get_personal_records(u_id1)
            records_result2 = await self.personal_record_client.get_personal_records(u_id2)
            
            if records_result1.get("code") != 10000:
                error_msg = records_result1.get("err", "未知错误")
                yield event.plain_result(f"❌ 获取第一个用户的个人记录失败\n错误: {error_msg}").use_t2i(False)
                return
            
            if records_result2.get("code") != 10000:
                error_msg = records_result2.get("err", "未知错误")
                yield event.plain_result(f"❌ 获取第二个用户的个人记录失败\n错误: {error_msg}").use_t2i(False)
                return
            
            rank_data1 = records_result1.get("data", {}).get("rank", [])
            rank_data2 = records_result2.get("data", {}).get("rank", [])
            
            # 获取用户姓名（如果还没有）
            if not user_name1 and rank_data1:
                user_name1 = rank_data1[0].get("u_name", "未知用户")
            if not user_name2 and rank_data2:
                user_name2 = rank_data2[0].get("u_name", "未知用户")
            
            # 构建项目ID到记录的映射
            records1_map = {}
            for record in rank_data1:
                e_id = record.get("e_id")
                records1_map[e_id] = record
            
            records2_map = {}
            for record in rank_data2:
                e_id = record.get("e_id")
                records2_map[e_id] = record
            
            # 获取所有项目的并集（两个用户有成绩的项目）
            all_event_ids = set(records1_map.keys()) | set(records2_map.keys())
            
            if not all_event_ids:
                yield event.plain_result(
                    f"❌ {user_name1} 和 {user_name2} 都没有个人记录，无法进行对比"
                ).use_t2i(False)
                return
            
            # 按项目ID排序
            sorted_event_ids = sorted(all_event_ids)
            
            # 准备输出行
            output_lines = []
            output_lines.append(f"{user_name1}（{u_id1}） vs {user_name2}（{u_id2}）")
            
            # 统计胜负
            player1_wins = 0
            player2_wins = 0
            
            pk_results = []
            
            for e_id in sorted_event_ids:
                record1 = records1_map.get(e_id)
                record2 = records2_map.get(e_id)
                
                # 获取项目代码
                event_code = EVENT_ID_TO_CODE.get(e_id)
                if not event_code:
                    event_code = f"项目{e_id}"
                
                # 获取成绩
                time_single1_ms = record1.get("time_single") if record1 else None
                time_avg1_ms = record1.get("time_avg") if record1 else None
                time_single2_ms = record2.get("time_single") if record2 else None
                time_avg2_ms = record2.get("time_avg") if record2 else None
                
                # 格式化成绩
                single1 = "-"
                if time_single1_ms and time_single1_ms != 999999:
                    single1 = self.format_time_ms(time_single1_ms)
                
                avg1 = "-"
                if time_avg1_ms and time_avg1_ms != 999999:
                    avg1 = self.format_time_ms(time_avg1_ms)
                
                single2 = "-"
                if time_single2_ms and time_single2_ms != 999999:
                    single2 = self.format_time_ms(time_single2_ms)
                
                avg2 = "-"
                if time_avg2_ms and time_avg2_ms != 999999:
                    avg2 = self.format_time_ms(time_avg2_ms)
                
                # 转换为毫秒用于比较
                single1_ms = parse_time_to_ms(single1) if single1 != "-" else None
                avg1_ms = parse_time_to_ms(avg1) if avg1 != "-" else None
                single2_ms = parse_time_to_ms(single2) if single2 != "-" else None
                avg2_ms = parse_time_to_ms(avg2) if avg2 != "-" else None
                
                # 判断单次胜负
                single_winner = compare_times(single1_ms, single2_ms)
                avg_winner = compare_times(avg1_ms, avg2_ms)
                
                # 判断项目胜负（只要有一项获胜或对方两项都无效，则获胜）
                # 如果一方没有成绩，另一方获胜
                has_record1 = (single1 != "-" or avg1 != "-")
                has_record2 = (single2 != "-" or avg2 != "-")
                
                if not has_record1 and has_record2:
                    # 用户2获胜
                    player2_wins += 1
                    project_winner = 2
                elif has_record1 and not has_record2:
                    # 用户1获胜
                    player1_wins += 1
                    project_winner = 1
                else:
                    # 双方都有成绩或都没成绩
                    if single_winner == 1 or avg_winner == 1:
                        player1_wins += 1
                        project_winner = 1
                    elif single_winner == -1 or avg_winner == -1:
                        player2_wins += 1
                        project_winner = 2
                    else:
                        project_winner = 0  # 平局
                
                # 标记胜负符号：左侧胜者用★，右侧胜者用☆，败者不显示标记
                single1_mark = "★" if single_winner == 1 else ""
                single2_mark = "☆" if single_winner == -1 else ""
                avg1_mark = "★" if avg_winner == 1 else ""
                avg2_mark = "☆" if avg_winner == -1 else ""
                
                # 收集数据，稍后格式化
                pk_results.append({
                    "event_code": event_code,
                    "event_code_len": len(event_code),
                    "single1": single1,
                    "single2": single2,
                    "avg1": avg1,
                    "avg2": avg2,
                    "single1_mark": single1_mark,
                    "single2_mark": single2_mark,
                    "avg1_mark": avg1_mark,
                    "avg2_mark": avg2_mark,
                })
            
            # 计算最大项目名长度（用于对齐第二行）
            max_event_code_len = max([r["event_code_len"] for r in pk_results]) if pk_results else 0
            
            # 计算单次和平均成绩的最大宽度（用于对齐）
            max_single_width = 0
            max_avg_width = 0
            for pk_result in pk_results:
                max_single_width = max(max_single_width, len(pk_result["single1"]), len(pk_result["single2"]))
                max_avg_width = max(max_avg_width, len(pk_result["avg1"]), len(pk_result["avg2"]))
            
            # 构建所有行的左边部分（|| 前的部分），用于计算最大宽度
            left_parts = []
            right_parts = []
            for pk_result in pk_results:
                event_code = pk_result["event_code"]
                single1 = pk_result["single1"]
                single2 = pk_result["single2"]
                avg1 = pk_result["avg1"]
                avg2 = pk_result["avg2"]
                single1_mark = pk_result["single1_mark"]
                single2_mark = pk_result["single2_mark"]
                avg1_mark = pk_result["avg1_mark"]
                avg2_mark = pk_result["avg2_mark"]
                
                # 第一行：项目名 + 空格 + 标记 + 空格 + 单次成绩（左侧，右对齐）
                left1 = f"{event_code} {single1_mark} {single1:>{max_single_width}}"
                # 第二行：空白（与项目名同宽）+ 空格 + 标记 + 空格 + 平均成绩（左侧，右对齐）
                left2 = f"{'':>{max_event_code_len}} {avg1_mark} {avg1:>{max_single_width}}"
                
                # 右侧部分：单次成绩（右对齐）+ 空格 + 标记（第一行）
                right1 = f"{single2:>{max_avg_width}} {single2_mark}"
                # 平均成绩（右对齐）+ 空格 + 标记（第二行）
                right2 = f"{avg2:>{max_avg_width}} {avg2_mark}"
                
                left_parts.append((left1, left2))
                right_parts.append((right1, right2))
            
            # 计算所有行中 || 前的最大长度（用于对齐 ||）
            max_left_width = 0
            for left1, left2 in left_parts:
                max_left_width = max(max_left_width, len(left1), len(left2))
            
            # 格式化输出，对齐 ||
            for i, pk_result in enumerate(pk_results):
                left1, left2 = left_parts[i]
                right1, right2 = right_parts[i]
                
                # 补齐左边部分到最大宽度，确保 || 对齐
                left1_padded = left1.ljust(max_left_width)
                left2_padded = left2.ljust(max_left_width)
                
                # 构建完整行
                line1 = f"{left1_padded} || {right1}"
                line2 = f"{left2_padded} || {right2}"
                
                output_lines.append(line1)
                output_lines.append(line2)
            
            # 添加比分和结果
            output_lines.append(f"结果: (🌟){player1_wins}:{player2_wins}")
            if player1_wins > player2_wins:
                output_lines.append(f"{user_name1}​胜利！")
            elif player2_wins > player1_wins:
                output_lines.append(f"{user_name2}​胜利！")
            else:
                output_lines.append("平局！")
            
            response_text = "\n".join(output_lines)
            yield event.plain_result(response_text).use_t2i(False)
            
        except Exception as e:
            logger.error(f"PK对比异常: {e}")
            yield event.plain_result(f"❌ 执行出错: {str(e)}").use_t2i(False)

